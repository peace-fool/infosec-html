Don't cheat!
This ain't HackTheBox, stop digging further.